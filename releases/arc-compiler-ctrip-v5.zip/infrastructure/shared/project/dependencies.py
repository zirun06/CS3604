"""Install the generated workspace's npm dependencies before each TDD run."""

from pathlib import Path
import subprocess
from threading import Thread

from infrastructure.utils.processes import npm_command, start_process, stop_process


def install_dependencies(output_dir: Path, timeout: int = 600) -> None:
    """Run npm install in the generated workspace, stream its output, and fail on timeout or nonzero exit."""
    if not (output_dir / "package.json").is_file():
        raise ValueError("Run 00_project_initialization.py before installing project dependencies")
    command = npm_command()
    print(f"Installing dependencies in {output_dir}: npm install --include=dev --no-audit --no-fund", flush=True)
    with start_process(
        [*command, "install", "--include=dev", "--no-audit", "--no-fund"],
        cwd=output_dir, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", bufsize=1,
    ) as process:
        # Forward child output through Python so the console log also receives it.
        def forward_output():
            """Forward npm output through Python so both the terminal and compiler.log receive it."""
            for line in process.stdout:
                print(line, end="", flush=True)

        reader = Thread(target=forward_output, daemon=True)
        reader.start()
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired as error:
            stop_process(process)
            raise RuntimeError(f"npm install timed out after {timeout} seconds") from error
        except BaseException:
            stop_process(process)
            raise
        finally:
            reader.join()
        if process.returncode:
            raise RuntimeError(f"npm install failed with exit code {process.returncode}; see the npm output above")
